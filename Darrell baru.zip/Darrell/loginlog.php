<?php
require 'koneksi.php';
if (isset($_POST['submit'])) {
$username = $_POST["username"];
$password = $_POST["password"];

$query_sql = "SELECT * FROM users
            WHERE username = '$username' AND password = '$password'";

$result = mysqli_query($koneksi, $query_sql);

if (mysqli_num_rows($result) > 0) {
    header("Location: index.php");
} else {
  echo '<script>alert("Email atau Password Anda Salah. Silahkan Coba Login Kembali.");</script>';
}
}
?>