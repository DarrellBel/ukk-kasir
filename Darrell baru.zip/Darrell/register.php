<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="register.css">
</head>
<body>
<body>
    <header class="header">
        <h1>APLIKASI KASIR</h1>
    </header>

    <nav class="navbar navbar-expand-lg navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="login.php">Login</a>
            </li>
        </ul>
    </nav>


    <div class="container">
        <h2>REGISTER</h2>
            <form action="tambah.php" method="POST">
                <!-- username -->
                <label for="username">Username:</label>
                <input type="text" id="username" placeholder="Masukkan Username" name="username" value="" required>

                <!-- Password -->
                <label for="password">Password:</label>
                <input type="password" id="password" placeholder="Masukkan Password" name="password" value="" required>

                <!-- Email -->
                <label for="email">Email:</label>
                <input type="email" id="email" placeholder="Masukkan Email" name="email" value="" required>

                <!-- Role -->
                <label for="role">Role:</label>

                <input type="radio" id="user" name="role" value="user">
                <label for="user">User</label>

                <input type="radio" id="admin" name="role" value="admin">
                <label for="admin">Admin</label>

                <input type="radio" id="petugas" name="role" value="petugas">
                <label for="petugas">Petugas</label>

                <button input type="submit" name="submit" value="submit"> Register<br> </button>
            </form> <br>
            Already Have an Account?
        <a href="login.php">
        Login
        </a> <br><br>
    </div>
<footer class="footer">
            <p>&copy;2024 Kasir App</p>
        </footer>
</body>
</html>