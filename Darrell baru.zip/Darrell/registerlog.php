<?php
include 'koneksi.php';
if (isset($_POST['submit'])) {


  $username = $_POST["username"];
  $password = $_POST["password"];
  $role = $_POST["role"];


  $query_sql = "INSERT INTO users (username, password, role) 
            VALUES ('$username', '$password', '$role')";

  if (mysqli_query($config, $query_sql)) {
    header("Location: login.php");
  } else {
    echo "Pendaftaran Gagal : " . mysqli_error($koneksi);
  }
}

?>