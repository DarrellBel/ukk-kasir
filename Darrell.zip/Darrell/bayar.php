<?php
session_start();
include "koneksi.php";

// Check if the user is logged in and is an admin
if (empty($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    echo "<script>
    alert('You are not allowed to access this page!');
    window.location.href = 'login.php';
    </script>";
    exit(); // Exit the script after redirecting
}

// Query untuk menghitung jumlah data di tabel kasir
$sqlCheck = "SELECT COUNT(*) AS total FROM kasir";
$resultCheck = mysqli_query($koneksi, $sqlCheck);
$rowCheck = mysqli_fetch_assoc($resultCheck);
$totalRows = $rowCheck['total'];

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Ambil total bayar dari form
    $totalBayar = $_POST['total_bayar'];

    // Proses pembayaran (misalnya, simpan ke database atau lakukan proses lainnya)

    // Hapus semua data dari tabel kasir jika ada
    $sql = "TRUNCATE TABLE kasir";
    $result = mysqli_query($koneksi, $sql);

    if ($result) {
        echo "<script>
        alert('Pembayaran berhasil');
        window.location.href = 'pembayaran.php';
        </script>";
        exit();
    } else {
        echo "<script>
        alert('Gagal melakukan pembayaran');
        window.location.href = 'pembayaran.php';
        </script>";
        exit();
    }
}

// Jika tidak ada data yang bisa dihapus, redirect ke pembayaran.php dengan menambahkan parameter query string "empty"
if ($totalRows == 0) {
    header("Location: pembayaran.php?empty");
    exit();
}
?>
