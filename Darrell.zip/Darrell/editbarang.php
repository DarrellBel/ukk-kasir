<?php 
session_start();
include "koneksi.php";

// Check if the user is logged in and is an admin
if (empty($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    echo "<script>
    alert('You are not allowed to access this page!');
    window.location.href = 'login.php';
    </script>";
    exit(); // Exit the script after redirecting
}
?>

<?php
include 'koneksi.php';

// Periksa apakah parameter id telah diteruskan
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: login.php");
    exit();
}

// Ambil ID barang dari parameter
$id = $_GET['id'];

// Query untuk mengambil data barang berdasarkan ID
$sql = "SELECT * FROM barang WHERE id = $id";
$result = mysqli_query($koneksi, $sql);

if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
} else {
    echo "Barang tidak ditemukan.";
    exit();
}

// Proses form jika dikirimkan
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    // Query untuk mengupdate data barang
    $sql = "UPDATE barang SET nama='$nama', harga='$harga', stok='$stok' WHERE id=$id";
    $update_result = mysqli_query($koneksi, $sql);

    if ($update_result) {
        echo "<script>alert('Data barang berhasil diupdate.'); window.location.href='index.php';</script>";
        exit();
    } else {
        echo "Gagal mengupdate data: " . mysqli_error($koneksi);
    }
}

mysqli_close($koneksi);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link rel="stylesheet" href="register.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>


<header class="header">
    <h1>APLIKASI KASIR</h1>
</header>

<nav class="navbar navbar-expand-lg navbar-light">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
        </li>
        <li class="nav-item">
                <a class="nav-link" href="kasir.php">Kasir</a>
            </li>
        <li class="nav-item">
            <a class="nav-link" href="pembayaran.php">Pembayaran</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="tambahbarang.php">Tambah Barang</a>
        </li>
        <li class="nav-item"> 
            <a class="nav-link" href="logout.php">Logout</a>
        </li>
    </ul>
</nav>

<div class="container mt-4">
        <h2>Edit Barang</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>" method="post">
            <div class="form-group">
                <label for="nama">Nama Barang:</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $row['nama']; ?>" required>
            </div>
            <div class="form-group">
                <label for="harga">Harga Barang:</label>
                <input type="text" class="form-control" id="harga" name="harga" value="<?php echo $row['harga']; ?>" required>
            </div>
            <div class="form-group">
                <label for="stok">Stok Barang:</label>
                <input type="text" class="form-control" id="stok" name="stok" value="<?php echo $row['stok']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
    

<footer class="footer">
    <p>&copy;2024 Kasir App</p>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="koneksi.php"></script>
</body>

</html>
