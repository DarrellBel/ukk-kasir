<?php
$koneksi = mysqli_connect("localhost","root","","kasir_db");

function query($query){
	global $koneksi;
	$result = mysqli_query($koneksi, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}

function tambahpelanggan($post){
	global $koneksi;
	$NamaPelanggan = $post["NamaPelanggan"];
	$alamat = $post["alamat"];
	$NomorTelepon = $post["NomorTelepon"];

	$query = "INSERT INTO pelanggan VALUES('','$NamaPelanggan','$alamat','$NomorTelepon')";

	mysqli_query($koneksi, $query);
	return mysqli_affected_rows($koneksi);

}
function ubahpelanggan($post){
	global $koneksi;
	$pelangganID = $post["pelangganID"];
	$NamaPelanggan = $post["NamaPelanggan"];
	$alamat = $post["alamat"];
	$NomorTelepon = $post["NomorTelepon"];

	$query = "UPDATE pelanggan SET
			  NamaPelanggan = '$NamaPelanggan',
			  alamat = '$alamat',
			  NomorTelepon = '$NomorTelepon'
			  WHERE pelangganID = $pelangganID
			  ";

	mysqli_query($koneksi, $query);
	return mysqli_affected_rows($koneksi);
}
function hapuspelanggan($pelangganID){
	global $koneksi;
	mysqli_query($koneksi,"DELETE  FROM pelanggan WHERE pelangganID = $pelangganID");
	return mysqli_affected_rows($koneksi);
}

function tambah($post){
	global $koneksi;
	$NamaProduk = $post["NamaProduk"];
	$Harga = $post["Harga"];
	$Stok = $post["Stok"];


	$query = "INSERT INTO produk VALUES('','$NamaProduk','$Harga','$Stok')";

	mysqli_query($koneksi, $query);
	return mysqli_affected_rows($koneksi);


}

function ubah($post){
	global $koneksi;
	$ProdukID = $post["ProdukID"];
	$NamaProduk = $post["NamaProduk"];
	$Harga = $post["Harga"];
	$Stok = $post["Stok"];

	$query = "UPDATE produk SET
			  NamaProduk = '$NamaProduk',
			  Harga = '$Harga',
			  Stok = '$Stok'
			  WHERE ProdukID = $ProdukID
			  ";

	mysqli_query($koneksi, $query);
	return mysqli_affected_rows($koneksi);

}

function hapus($ProdukID){
	global $koneksi;
	mysqli_query($koneksi,"DELETE  FROM produk WHERE ProdukID = $ProdukID");
	return mysqli_affected_rows($koneksi);
}

function registrasi($data){
global $koneksi;
$username = strtolower(stripslashes($data["username"]));
  $password = mysqli_real_escape_string($koneksi, $data["password"]);
        $password2 = mysqli_real_escape_string($koneksi, $data["password2"]);

$result = mysqli_query($koneksi, "SELECT username FROM user WHERE username = '$username'");
if(mysqli_fetch_assoc($result)){
	echo "
	<script>
	alert('user sudah terdaftar');
	</script>
	";
	return false;
}
if($password !== $password2){
	echo "
	<script>
	alert('Konfirmasi Password anda salah');
	</script>
	";
	return false;
}

$password = password_hash($password, PASSWORD_DEFAULT);
mysqli_query($koneksi, "INSERT INTO user VALUES('','$username','$password','petugas')");
return mysqli_affected_rows($koneksi);

}

function tambahdetail($post){
	global $koneksi;
	$PenjualanID = $post["PenjualanID"];
	$ProdukID = $post["ProdukID"];
	$JumlahProduk = $post["JumlahProduk"];
	$SubTotal = $post["SubTotal"];

	$query = "INSERT INTO detailpenjualan VALUES('','$PenjualanID','$ProdukID','$JumlahProduk','$SubTotal')";

	mysqli_query($koneksi, $query);
	return mysqli_affected_rows($koneksi);
}

function ubahdetail($post){
	global $koneksi;
	$DetailID = $post["DetailID"];
	$PenjualanID = $post["PenjualanID"];
	$ProdukID = $post["ProdukID"];
	$JumlahProduk = $post["JumlahProduk"];
	$SubTotal = $post["SubTotal"];

	$query = "UPDATE detailpenjualan SET
			  PenjualanID = '$PenjualanID',
			  ProdukID = '$ProdukID',
			  JumlahProduk = '$JumlahProduk',
			   SubTotal = '$SubTotal'
			  WHERE DetailID = $DetailID
			  ";

	mysqli_query($koneksi, $query);
	return mysqli_affected_rows($koneksi);

}

function hapusdetail($DetailID){
	global $koneksi;
	mysqli_query($koneksi,"DELETE  FROM detailpenjualan WHERE DetailID = $DetailID");
	return mysqli_affected_rows($koneksi);
}


function tambahbarang($post){
	global $koneksi;
    $id = $post["id"];
	$nama = $post["nama"];
	$harga = $post["harga"];
	$stok = $post["stok"];

	$query = "INSERT INTO barang VALUES('','$nama','$harga','$stok')";

	mysqli_query($koneksi, $query);
	return mysqli_affected_rows($koneksi);

}
function ubahbarang($post){
	global $koneksi;
    $id = $post["id"];
    $nama = $post["nama"];
	$harga = $post["harga"];
	$stok = $post["stok"];

	$query = "UPDATE barang SET
			  nama = '$nama',
			  harga = '$harga',
			  stok = '$stok'
			  WHERE id = $id
			  ";

	mysqli_query($koneksi, $query);
	return mysqli_affected_rows($koneksi);
}

function hapusbarang($id){
	global $koneksi;
	mysqli_query($koneksi,"DELETE  FROM barang WHERE id = $id");
	return mysqli_affected_rows($koneksi);
}
 ?>


