<?php
// Pastikan ada parameter id yang diterima
if(isset($_GET['id']) && !empty($_GET['id'])){
    // Include file koneksi.php
    include 'koneksi.php';

    // Escape input untuk mencegah SQL Injection
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);

    // Query untuk menghapus data berdasarkan id
    $sql = "DELETE FROM barang WHERE id = '$id'";
    if(mysqli_query($koneksi, $sql)){
        // Jika penghapusan berhasil, redirect kembali ke halaman index.php
        header("location: indexadm.php");
        exit();
    } else {
        // Jika terjadi kesalahan dalam penghapusan, tampilkan pesan error
        echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
    }

    // Tutup koneksi database
    mysqli_close($koneksi);
} else {
    // Jika parameter id tidak diterima atau kosong, tampilkan pesan error
    echo "Parameter id tidak valid.";
}
?>
