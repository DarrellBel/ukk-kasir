<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<link rel="stylesheet" href="style.css"><br>

    
    <table class="table">
        <thead>
            <tr>
                <th>Id Barang</th>
                <th>username Barang</th>
                <th>username Barang</th>
                <th>username Barang</th>
            </tr>
        </thead>
        <tbody>
            <tr>
            <td>buububu</td>
            <td> xcfgbdfg </td>
            <td> xcfgbdfg </td>
            <td> xcfgbdfg </td>
            </tr>
        </tbody>
    </table>
    <br><br><br><br><br><br>  <br><br><br><br><br><br>  <br><br><br><br><br><br>  <br><br><br><br>

   

</body>
</html>