<?php 
session_start();
include "koneksi.php";

// Check if the user is logged in and is an admin
if (empty($_SESSION['username']) || $_SESSION['role'] !== 'petugas') {
    echo "<script>
    alert('You are not allowed to access this page!');
    window.location.href = 'login.php';
    </script>";
    exit(); // Exit the script after redirecting
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Aplikasi Kasir - Daftar Barang</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    
<header class="header">
    <h1>APLIKASI KASIR</h1>
</header>

<nav class="navbar navbar-expand-lg navbar-light">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="indexpet.php">Home</a>
        </li>
        <li class="nav-item"> 
            <a class="nav-link" href="logout.php">Logout</a>
        </li>
    </ul>
</nav>

<div class="container mt-4">
    <h2>Daftar Barang</h2>
    <table class="table table-bordered">
        <thead class="thead-dark">
        <tr>
            <th>Kode Barang</th>
            <th>Nama Barang</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
        </thead>
        <tbody>
        <?php
     
        include 'koneksi.php';

      
        $sql = "SELECT * FROM barang";
        $result = mysqli_query($koneksi, $sql);

        
        if (mysqli_num_rows($result) > 0) {
       
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['nama'] . "</td>";
                echo "<td>" . $row['harga'] . "</td>";
                echo "<td>" . $row['stok'] . "</td>";
                echo "<td>
                        <a href='hapusbarang.php?id=" . $row['id'] . "' class='btn btn-danger'>Delete</a>
                      </td>"; 
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Tidak ada data</td></tr>";
        }

        // Tutup koneksi database
        mysqli_close($koneksi);
        ?>
        </tbody>
    </table>
</div>
    

<footer class="footer">
    <p>&copy;2024 Kasir App</p>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="koneksi.php"></script>
</body>

</html>
