<?php 

require 'function.php';

if(isset($_POST["submit"])) {
    $nama_barang = $_POST["nama"];
    $harga_barang = $_POST["harga"];
    $jumlah_barang = $_POST["jumlah"];
    $total_harga = $harga_barang * $jumlah_barang;

    if(tambahTransaksi($nama_barang, $harga_barang, $jumlah_barang, $total_harga) > 0) {
        echo "
        <script>
        alert('Transaksi berhasil dicatat');
        document.location.href='indexpelanggan.php';
        </script>
        ";
    } else {
        echo "
        <script>
        alert('Transaksi gagal dicatat');
        document.location.href='indexpelanggan.php';
        </script>
        ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Aplikasi Kasir - Catat Transaksi</title>
    <link rel="stylesheet" href="register.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
<header class="header">
        <h1>APLIKASI KASIR</h1>
    </header>

    <nav class="navbar navbar-expand-lg navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="indexadm.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="kasir.php">Kasir</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="pembayaran.php">Pembayaran</a>
        </li>
            <li class="nav-item">
                <a class="nav-link" href="tambahbarang.php">Tambah Barang</a>
            </li>
            <li class="nav-item"> 
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </nav>

    <div class="container">
        <h2>Catat Transaksi</h2>
        <form action="kasirlog.php" method="POST">
            <!-- nama -->
            <label for="nama">Nama Barang:</label>
            <input type="text" id="nama" placeholder="Masukkan Nama Barang" name="nama" required>

            <!-- harga -->
            <label for="harga">Harga Barang:</label>
            <input type="text" id="harga" placeholder="Masukkan Harga Barang" name="harga" required>

            <!-- jumlah -->
            <label for="jumlah">Jumlah Barang:</label>
            <input type="number" id="jumlah" placeholder="Masukkan Jumlah Barang" name="jumlah" required>

            <br><br>
            <button type="submit" name="submit" value="submit">Catat Transaksi</button>
        </form><br>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="config.php"></script>
    
    <footer class="footer">
        <p>&copy;2024 Kasir App</p>
    </footer>
</body>

</html>
