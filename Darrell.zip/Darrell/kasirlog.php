<?php
include ('koneksi.php');

if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $jumlah = $_POST['jumlah'];

    $sqlquery = "INSERT INTO kasir (nama,harga,jumlah)
                VALUES('$nama','$harga','$jumlah')";

    $result = mysqli_query($koneksi,$sqlquery);

    if ($result) {
        echo "<script>
        alert('Transaction Created Succesfully');
        window.location.href = 'kasir.php';
        </script>";

        exit();
    } else {
        echo "Failed: " . mysqli_error($koneksi);
    }
}

?>