<?php
include("koneksi.php");
session_start();

if (isset($_POST['submit'])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $query = "SELECT * FROM users
    WHERE username = '$username' AND password = '$password'";
    $verify = mysqli_query($koneksi, $query);

    if ($verify && mysqli_num_rows($verify) > 0) {
        $row=mysqli_fetch_assoc($verify);
        $_SESSION['username'] = $row['username']; 
        header('Location:login.php');

    } else{
        echo "<script>
        alert('Username/Password Invalid');
        window.location.href = 'login.php';
        </script>";
    }
}


?>