<?php
session_start();

// Check if user is already logged in, redirect them to the homepage
if(isset($_SESSION['username'])) {
    // Redirect to the appropriate page based on user role
    switch ($_SESSION['role']) {
        case 'admin':
            header("Location: indexadm.php");
            exit();
        case 'petugas':
            header("Location: indexpet.php");
            exit();
        case 'user':
            header("Location: indexus.php");
            exit();
        default:
            // Handle unrecognized role here
            break;
    }
}

// Simpan URL halaman saat ini jika belum disimpan sebelumnya
if (!isset($_SESSION['redirect_url'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
}

// Tetapkan koneksi ke database
include('koneksi.php');

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $ambilrole = mysqli_query($koneksi, "SELECT * FROM user WHERE username = '$username'");
    $hitung = mysqli_num_rows($ambilrole);

    if ($hitung == 1) {
        $role = mysqli_fetch_assoc($ambilrole);
        
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $role['role'];

        // Redirect user back to the page they were on before logging in
        $redirect_url = isset($_SESSION['redirect_url']) ? $_SESSION['redirect_url'] : 'index.php';
        header("Location: $redirect_url");
        exit();
    } else {
        echo "<script>
              alert('Username not found.');
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Aplikasi Kasir - Login</title>
    <link rel="stylesheet" href="login.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
<header class="header">
        <h1>APLIKASI KASIR</h1>
    </header>

    <div class="container">
        <h2>LOGIN</h2>
        <form id=loginForm action="loginlog.php" method="POST">
            <div class="form-group">
                <label for="username">Username: </label>
                <input type="text" id="username" placeholder="Masukkan Username" name="username" required>
            </div>

            <div class="form-group">
                <label for="password">Password: </label>
                <input type="password" id="password" placeholder="Masukkan Password" name="password" required>
            </div>
            <button type="submit" name="submit" >Login</button>
        </form>
        <br>
            Haven't Registered yet?
        <a href="register.php">
        Register
        </a> <br><br>
        <div id="message"></div>
    </div>
    <footer class="footer">
        <p>&copy;2024 Kasir App</p>
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="koneksi.php"></script>
</body>

</html>
