<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale = 1.0">
    <title>Aplikasi Kasir-Halaman Login</title>
    <link rel="stylesheet" href="register.css">
</head>

<body>
    <header class="header">
        <h1>APLIKASI KASIR</h1>
    </header>

    <nav class="navbar">
        <ul>
            <li>
                <a href="index.php"> Home </a>
            </li>

        </ul>
    </nav>
    <div class="container">
        <h2>LOGIN</h2>
        <form id=loginForm action="loginlog.php" method="POST">
            <div class="form-group">
                <label for="username">Username: </label>
                <input type="text" id="username" placeholder="Masukkan Username" name="username" required>
            </div>

            <div class="form-group">
                <label for="password">Password: </label>
                <input type="password" id="password" placeholder="Masukkan Password" name="password" required>
            </div>
            <button type="submit" name="submit" >Login</button>
        </form>

        <div id="message"></div>
    </div>
    <footer class="footer">
            <p>&copy;2024 Kasir App</p>
        </footer>
    <script src="config.php"></script>
</body>

</html>