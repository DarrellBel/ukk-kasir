<?php
include("koneksi.php");
session_start();

if (isset($_POST['submit'])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $query = "SELECT * FROM users
    WHERE username = '$username' AND password = '$password'";
    $verify = mysqli_query($koneksi, $query);

    if ($verify && mysqli_num_rows($verify) > 0) {
        $row=mysqli_fetch_assoc($verify);
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $row['role']; // Corrected from $role['role'] to $row['role']
        
        switch ($_SESSION['role']) {
            case 'admin':
                header("Location: indexadm.php");
                exit();
            case 'user':
                header("Location: indexus.php");
                exit();
            case 'petugas':
                header("Location: indexpet.php");
                exit();
            default:
                echo "<script>
                      alert('Role not recognized.');
                      window.location.href = 'login.php';
                      </script>";
        }

    } else {
        echo "<script>
        alert('Username/Password Invalid');
        window.location.href = 'login.php';
        </script>";
    }
}
?>
