<?php
session_start();
include "koneksi.php";

// Check if the user is logged in and is an admin
if (empty($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    echo "<script>
    alert('You are not allowed to access this page!');
    window.location.href = 'login.php';
    </script>";
    exit(); // Exit the script after redirecting
}

// Query untuk menghitung jumlah data di tabel kasir
$sqlCheck = "SELECT COUNT(*) AS total FROM kasir";
$resultCheck = mysqli_query($koneksi, $sqlCheck);
$rowCheck = mysqli_fetch_assoc($resultCheck);
$totalRows = $rowCheck['total'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Aplikasi Kasir - Pembayaran</title>
    <link rel="stylesheet" href="pembayaran.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    
<header class="header">
    <h1>APLIKASI KASIR</h1>
</header>

<nav class="navbar navbar-expand-lg navbar-light">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="indexadm.php">Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="kasir.php">Kasir</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="pembayaran.php">Pembayaran</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="tambahbarang.php">Tambah Barang</a>
        </li>
        <li class="nav-item"> 
            <a class="nav-link" href="logout.php">Logout</a>
        </li>
    </ul>
</nav>

<div class="container mt-4">
    <h2>Pembayaran</h2>
    <?php
    include "koneksi.php";

    // Ambil data dari tabel kasir
    $sql = "SELECT * FROM kasir";
    $result = mysqli_query($koneksi, $sql);

    if (mysqli_num_rows($result) > 0) {
        echo "<table class='table table-bordered'>
                <thead class='thead-dark'>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>";
        $totalBayar = 0;
        $no = 1;
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>$no</td>
                    <td>" . $row['nama'] . "</td>
                    <td>" . $row['harga'] . "</td>
                    <td>" . $row['jumlah'] . "</td>
                    <td>" . $row['harga'] * $row['jumlah'] . "</td>
                </tr>";
            $totalBayar += ($row['harga'] * $row['jumlah']);
            $no++;
        }
        echo "<tr>
                <td colspan='4'><b>Total Bayar</b></td>
                <td><b>$totalBayar</b></td>
            </tr>";
        echo "</tbody></table>";
    } else {
        echo "<p>Tidak ada transaksi.</p>";
    }
    ?>
  <form action="bayar.php" method="post">
    <input type="hidden" name="total_bayar" value="<?php echo $totalBayar; ?>">
    <button type="submit" class="btn btn-primary" name="submit" <?php echo $totalRows == 0 ? 'disabled' : ''; ?>>Bayar</button>
</form>
    <?php
    // Tampilkan notifikasi jika parameter query string 'empty' ada
    if (isset($_GET['empty'])) {
        echo "<script>alert('Tidak ada produk yang harus dibayar');</script>";
    }
    ?>
</div>

<footer class="footer">
    <p>&copy;2024 Kasir App</p>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
