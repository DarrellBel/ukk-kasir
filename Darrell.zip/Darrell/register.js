document.getElementById('registerForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    const username =
        document.getElementById('username').value;
    const password =
        document.getElementById('password').value;
    const role =
        document.getElementById('role').value;

    const responesec = awaitfetch('php/registerlog.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, role })
    });

    const result = awaitresponse.json();
    if (result.success) {
        alert('Registration succesful');
        window.location.href = 'login.php';
    } else {
        alert('Registration failed:' + result.message);
    }
});
