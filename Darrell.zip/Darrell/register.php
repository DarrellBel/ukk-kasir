<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Aplikasi Kasir - Register</title>
    <link rel="stylesheet" href="register.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <header class="header">
        <h1>APLIKASI KASIR</h1>
    </header>


    <div class="container">
        <h2>REGISTER</h2>
        <form action="tambah.php" method="POST">
            <!-- username -->
            <label for="username">Username:</label>
            <input type="text" id="username" placeholder="Masukkan Username" name="username" value="" required>

            <!-- Password -->
            <label for="password">Password:</label>
            <input type="password" id="password" placeholder="Masukkan Password" name="password" value="" required>

            <!-- Email -->
            <label for="email">Email:</label>
            <input type="email" id="email" placeholder="Masukkan Email" name="email" value="" required>


            <!-- Role -->
            <label for="role">Role:</label>
            <select id="one" name="role">
                <option id="role" name="role" value="user"> User </option>
                <option id="role" name="role" value="admin"> Admin </option>
                <option id="role" name="role" value="petugas"> Petugas </option>
            </select>
<br>
<br>
<br>
<br>
<br>
            <button input type="submit" name="submit" value="submit"> Register<br> </button>
        </form> <br>
        Already Have an Account?
        <a href="login.php">
            Login
        </a> <br><br>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="config.php"></script>
    <footer class="footer">
        <p>&copy;2024 Kasir App</p>
    </footer>
</body>

</html>