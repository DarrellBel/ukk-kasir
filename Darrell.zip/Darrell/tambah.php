<?php
include('koneksi.php');

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    $sqlquery = "INSERT INTO users(username, password, email, role) 
                 VALUES('$username', '$password', '$email', '$role')";

    $result = mysqli_query($koneksi, $sqlquery);

    if ($result) {
        echo "<script>
        alert('Account Created Succesfully');
        window.location.href = 'login.php';
        </script>";
  exit();
     } else {
        echo "Failed: " . mysqli_error($conn);
     }

}


 ?>