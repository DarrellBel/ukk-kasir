<?php
include ('koneksi.php');

if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $sqlquery = "INSERT INTO barang (nama,harga,stok)
                VALUES('$nama','$harga','$stok')";

    $result = mysqli_query($koneksi,$sqlquery);

    if ($result) {
        echo "<script>
        alert('New Data Created Succesfully');
        window.location.href = 'indexadm.php';
        </script>";

        exit();
    } else {
        echo "Failed: " . mysqli_error($koneksi);
    }
}

?>